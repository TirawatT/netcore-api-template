﻿using $safeprojectname$.Data.Context;
using $safeprojectname$.Data.Repositorys.Base;
using $safeprojectname$.Models.Table;

namespace $safeprojectname$.Data.Repositorys
{
    public class EmployeeRepository(MyDbContext context) : Repository<Employee, MyDbContext>(context)
    {

        public IEnumerable<Employee> GetAll(string department = "")
        {
            var res = base.GetAll();
            if (!string.IsNullOrEmpty(department))
                res = res.Where(w => w.Department == department);
            res = res.Take(5);
            return res;
        }
    }
}
