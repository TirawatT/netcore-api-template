using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Models.Dtos.Authorize;
using $safeprojectname$.Services.Authen;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    public class AuthorizeController(AuthorizeService _service) : ControllerBase
    {
        [HttpPost, Route("Login")]
        public IActionResult Login([FromBody] LoginRequestDto item) => Ok(_service.Login(item));

    }
}
