﻿namespace $safeprojectname$.Models.Dtos.Authorize
{
    public class LoginRequestDto
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
