﻿namespace $safeprojectname$.Models.Dtos.Authorize
{
    public class UserDto
    {
        public string? Username { get; set; }
        public string? Email { get; set; }
    }
}
